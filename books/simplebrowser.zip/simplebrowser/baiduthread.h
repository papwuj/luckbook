#ifndef BAIDUTHREAD_H
#define BAIDUTHREAD_H


#include "webview.h"
#include <QThread>


class BaiduThread : public QThread
{
    Q_OBJECT
public:
    explicit BaiduThread(WebView * webView, QString url, QString code);
    ~BaiduThread();
protected:
    void run();

signals:
    void isDone();  //处理完成信号

signals:

public slots:

private:
    WebView * m_webView;
    QString m_url;
    QString m_code;

};

#endif // BAIDUTHREAD_H
