#include "mythread.h"
#include <QFile>
#include <QWaitCondition>

MyThread::MyThread(QObject *parent): QThread(parent)
    ,m_stringList(nullptr)
{
    this->getFileContent();
    m_lockedMutex = new QMutex;
    m_waitCondition = new QWaitCondition;
}

MyThread::~MyThread(){}

void MyThread::run()
{
    for (int i = 0; i < this->m_stringList->size(); i++) {
        QString line = this->m_stringList->at(i);
        QStringList splitStr = line.split("	");
        if(splitStr.size() > 1) {
            QString url = splitStr.at(0).simplified();
            QString code = splitStr.at(1).simplified();

            QStringList* scripts = new QStringList();
            scripts->append("document.getElementById('swidZRxd').value = '"+code+"'");
            scripts->append("document.getElementById('zql7p47').firstChild.click()");
            scripts->append("var _interval_1 = setInterval(function(){if(document.querySelector(\".module-yun-tip\").style.display == \"none\"){Array.prototype.forEach.call(document.getElementsByClassName('EOGexf'),function(item){item.click();});clearInterval(_interval_1);}},1000);");
            scripts->append("var _interval_2 = setInterval(function(){if(document.querySelector(\".module-yun-tip\").style.display == \"none\"){document.querySelector(\"a[title='保存到网盘']\").click();clearInterval(_interval_2);}},1000);");
            scripts->append("var _interval_3 = setInterval(function(){if(document.querySelector(\".module-yun-tip\").style.display == \"none\"){document.querySelector('ul.treeview-root-content li').firstChild.click();document.querySelector(\"div.dialog-footer a[title='确定']\").click();clearInterval(_interval_3);window.location.href = \"https://www.baidu.com/\";}},1000);");

            qDebug() << url << " : " << code << endl;

            emit notify(url, code, scripts);

            m_lockedMutex->lock();
            m_waitCondition->wait(m_lockedMutex);
        }
    }

    emit isDone();
}

void MyThread::getFileContent(){
    m_stringList = new QStringList;
    QFile file("/Users/wujing/Workspaces/qt/simplebrowser/baidu.txt");
    if(!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug()<<"Can't open the file!"<<endl;
    }
    while(!file.atEnd())
    {
        QByteArray line = file.readLine();
        QString str(line);
        m_stringList->append(str);
    }
}

void MyThread::wake() {
    m_lockedMutex->unlock();
    m_waitCondition->wakeAll();
}

