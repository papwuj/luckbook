#ifndef MYTHREAD_H
#define MYTHREAD_H

#include "webview.h"
#include "tabwidget.h"
#include <QThread>
#include <QWaitCondition>


class MyThread : public QThread
{
    Q_OBJECT
public:
    explicit MyThread(QObject *parent = 0);
    ~MyThread();
    void getFileContent();

signals:
    void notify(QString url, QString code, QStringList*);
    void isDone();

public slots:
    void wake();

protected:
    void run();

private:
  QStringList* m_stringList;
  QMutex* m_lockedMutex;
  QWaitCondition* m_waitCondition;
};

#endif // MYTHREAD_H
