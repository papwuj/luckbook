#include "baiduthread.h"

BaiduThread::BaiduThread(WebView * webView, QString url, QString code)
{
    this->m_webView = webView;
    this->m_url = url;
    this->m_code = code;
}
BaiduThread::~BaiduThread() {

}

void BaiduThread::run()
{
    QStringList* scripts = new QStringList();
    scripts->append("document.getElementById('swidZRxd').value = '"+this->m_code+"'");
    scripts->append("document.getElementById('zql7p47').firstChild.click()");
    scripts->append("var _interval_1 = setInterval(function(){if(document.querySelector(\".module-yun-tip\").style.display == \"none\"){Array.prototype.forEach.call(document.getElementsByClassName('EOGexf'),function(item){item.click();});clearInterval(_interval_1);}},1000);");
    scripts->append("var _interval_2 = setInterval(function(){if(document.querySelector(\".module-yun-tip\").style.display == \"none\"){document.querySelector(\"a[title='保存到网盘']\").click();clearInterval(_interval_2);}},1000);");
    scripts->append("var _interval_3 = setInterval(function(){if(document.querySelector(\".module-yun-tip\").style.display == \"none\"){document.querySelector('ul.treeview-root-content li').firstChild.click();document.querySelector(\"div.dialog-footer a[title='确定']\").click();clearInterval(_interval_3);window.location.href = \"https://www.baidu.com/\";}},1000);");
    this->m_webView->setUrl(QUrl(this->m_url));

    QString finalUrl = this->m_webView->url().url();
    int i = 0;
    while(finalUrl != "https://www.baidu.com/" ) {
        qDebug() << this->m_url << " : " << i++;
        sleep(1000);
        finalUrl = this->m_webView->url().url();
    }

    emit isDone();  //发送完成信号
}
